import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-display-emp-details',
  imports: [CommonModule],
  templateUrl: './display-emp-details.html',
  styleUrl: './display-emp-details.css',
})
export class DisplayEmpDetails {
  empDetails = [
    {
      slNo: 1,
      name: 'Ravi',
      Salary: 90000,
      role: 'Developer',
      address: 'Tenali',
    },
    {
      slNo: 2,
      name: 'Rani',
      Salary: 60000,
      role: 'Front End developer',
      address: 'Tenali',
    },
    {
      slNo: 3,
      name: 'Teju',
      Salary: 80000,
      role: 'back End developer',
      address: 'Bangalore',
    },
    {
      slNo: 4,
      name: 'Raju',
      Salary: 150000,
      role: 'back End developer',
      address: 'Chennai',
    },
    {
      slNo: 5,
      name: 'Ravi',
      Salary: 90000,
      role: 'Developer',
      address: 'Tenali',
    },
    {
      slNo: 6,
      name: 'Rani',
      Salary: 60000,
      role: 'Front End developer',
      address: 'Tenali',
    },
    {
      slNo: 7,
      name: 'Teju',
      Salary: 80000,
      role: 'back End developer',
      address: 'Bangalore',
    },
    {
      slNo: 8,
      name: 'Raju',
      Salary: 150000,
      role: 'back End developer',
      address: 'Chennai',
    },
  ];

  deleteEmp(details: object) {
    let keys = Object.values(details);
    let filteredValue = this.empDetails.filter((value) => {
      return value.slNo != keys[0];
    });
    this.empDetails = filteredValue;
  }
}
