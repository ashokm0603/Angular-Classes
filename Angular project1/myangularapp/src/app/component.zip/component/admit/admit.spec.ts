import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Admit } from './admit';

describe('Admit', () => {
  let component: Admit;
  let fixture: ComponentFixture<Admit>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Admit]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Admit);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
