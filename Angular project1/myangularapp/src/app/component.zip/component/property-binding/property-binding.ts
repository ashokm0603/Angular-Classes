import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-property-binding',
  imports: [CommonModule, FormsModule],
  templateUrl: './property-binding.html',
  styleUrl: './property-binding.css',
})
export class PropertyBinding {
  /*message: String = 'hello';
  age: number = 10;
  isActive = false;
  display() {
    this.isActive = !this.isActive;
  } */

  username = '';
  password = '';
  email = '';
  userDetails: any[] = [];
  isDisplay = true;
  displayData() {
    this.isDisplay = false;
    console.log(this.userDetails);
  }

  submitData() {
    let userdata = {
      name: this.username,
      email: this.email,
      password: this.password,
    };
    this.userDetails.push(userdata);
    this.username = '';
    this.email = '';
    this.password = '';
  }
}
