import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-mouse-event',
  imports: [CommonModule],
  templateUrl: './mouse-event.html',
  styleUrl: './mouse-event.css',
})
export class MouseEvent {
  isDisplayHome = true;
  isDisplayLogin = true;
  isDisplayAbout = true;
  isDisplayServices = true;
  onHomePage() {
    this.isDisplayHome = false;
  }
  onLoginPage() {
    this.isDisplayLogin = false;
  }

  onHomePageHide() {
    this.isDisplayHome = true;
  }

  onAboutPage() {
    this.isDisplayAbout = false;
  }
  onServicesPage() {
    this.isDisplayServices = false;
  }
}
