import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreDefinePipes } from './pre-define-pipes';

describe('PreDefinePipes', () => {
  let component: PreDefinePipes;
  let fixture: ComponentFixture<PreDefinePipes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreDefinePipes]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreDefinePipes);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
