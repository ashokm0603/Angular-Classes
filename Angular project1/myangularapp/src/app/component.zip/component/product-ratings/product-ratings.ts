import { CommonModule } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product-ratings',
  imports: [CommonModule],
  templateUrl: './product-ratings.html',
  styleUrl: './product-ratings.css',
})
export class ProductRatings {
  @Input() productDetails: Array<any> = [];

  @Output() sendRatings = new EventEmitter<string>();

  submittedRatings(ratings: string, details: any) {
    details.ratings = ratings;
    this.sendRatings.emit(`Product Details: ${JSON.stringify(details)}`);
  }
}
