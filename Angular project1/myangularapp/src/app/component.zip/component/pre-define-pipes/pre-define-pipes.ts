import {
  CurrencyPipe,
  DatePipe,
  JsonPipe,
  LowerCasePipe,
  PercentPipe,
  SlicePipe,
  UpperCasePipe,
} from '@angular/common';
import { Component, Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverse',
})
export class ReversePipe implements PipeTransform {
  transform(value: string): any {
    return value.split('').reverse().join('');
  }
}

@Pipe({
  name: 'Gst',
})
export class GSTPipe implements PipeTransform {
  transform(value: number): any {
    return value / 10;
  }
}

@Component({
  selector: 'app-pre-define-pipes',
  imports: [
    PercentPipe,
    JsonPipe,
    DatePipe,
    UpperCasePipe,
    LowerCasePipe,
    CurrencyPipe,
    SlicePipe,
    ReversePipe,
    GSTPipe,
  ],
  templateUrl: './pre-define-pipes.html',
  styleUrl: './pre-define-pipes.css',
})
export class PreDefinePipes {
  title = 'EmpDetails ';
  name1 = 'RAVI';
  role1 = 'DeVeloPer';
  name2 = 'RANGAMMA';
  role2 = 'DAta AnAlYst';
  salary1 = 50000;
  salary2 = 900050;
  address1 = 'Tenali, AP';
  address2 = 'Bangalore, KA';
  arr = [10, 'html', true, null, 'Java'];
  todaysDate = new Date();
  number = 0.52345;
  obj = {
    name: 'ravi',
    role: 'developer',
    salary: '500000',
  };

  productDetails = [
    {
      name: 'laptop',
      productId: 'PD100',
      price: 5000,
    },
    {
      name: 'laptop Hp',
      productId: 'PD100',
      price: 150000,
    },
  ];
}
