import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ToastService, ScAngularToastify } from 'sc-angular-toastify';

export function EmailValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    let email = control.value;
    let domain = 'rvit.edu.in';
    if (email && !email.endsWith(domain)) {
      return { InvalidDomain: true };
    }
    return null;
  };
}

@Component({
  selector: 'app-student-registration',
  imports: [ReactiveFormsModule, CommonModule, ScAngularToastify],
  templateUrl: './student-registration.html',
  styleUrl: './student-registration.css',
})
export class StudentRegistration implements OnInit {
  studentGroup!: FormGroup;
  constructor(private sd: FormBuilder, private toast: ToastService) {}
  ngOnInit(): void {
    this.studentGroup = this.sd.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      age: ['', [Validators.required, Validators.min(18)]],
      email: ['', [Validators.required, EmailValidator()]],
      phone: ['', Validators.required],
      gender: ['', Validators.required],
      course: ['', Validators.required],
    });
  }
  //This is function will execute when user submitting form data
  formSubmitted() {
    console.log(this.studentGroup.value);
    if (this.studentGroup.invalid) {
      this.toast.show(` Please fill all fields 😥`, 'error', 3000, 'top-right');
    } else {
      this.toast.show(
        `${this.studentGroup.value.name}, Register Successfully`,
        'success',
        3000,
        'top-right'
      );
    }
  }
}
