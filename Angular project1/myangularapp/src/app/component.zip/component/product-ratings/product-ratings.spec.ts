import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductRatings } from './product-ratings';

describe('ProductRatings', () => {
  let component: ProductRatings;
  let fixture: ComponentFixture<ProductRatings>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductRatings]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductRatings);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
