import {
  CurrencyPipe,
  DatePipe,
  JsonPipe,
  LowerCasePipe,
  PercentPipe,
  SlicePipe,
  UpperCasePipe,
} from '@angular/common';
import { Component, Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverse',
  standalone: true,
})
class ReversePipe implements PipeTransform {
  transform(value: string): any {
    if (value!) {
      return '';
    } else {
      return value.split('').reverse().join();
    }
  }
}

@Component({
  selector: 'app-pipes-example',
  standalone: true,
  imports: [
    DatePipe,
    UpperCasePipe,
    LowerCasePipe,
    CurrencyPipe,
    PercentPipe,
    JsonPipe,
    SlicePipe,
    ReversePipe,
  ],
  templateUrl: './pipes-example.html',
  styleUrl: './pipes-example.css',
})
export class PipesExample {
  title = 'Pipes Example in Angular';
  name = 'Raju';
  salary = 10000;
  dob = new Date();
  marks = 0.51;
  para = ' RV INSTITUTE OF TECHNOLOGY';

  empDetails = {
    name: 'ravi',
    salary: 5000,
    role: 'developer',
  };
  Skills = ['html', 'css', 'Js', 'Node Js'];
}
