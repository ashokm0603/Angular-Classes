import { Component } from '@angular/core';

import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-admit',
  imports: [RouterLink, RouterOutlet],
  templateUrl: './admit.html',
  styleUrl: './admit.css',
})
export class Admit {}
