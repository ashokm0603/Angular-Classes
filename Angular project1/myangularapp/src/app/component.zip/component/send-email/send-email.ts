import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import emailjs from '@emailjs/browser';

@Component({
  selector: 'app-send-email',
  imports: [FormsModule],
  templateUrl: './send-email.html',
  styleUrl: './send-email.css',
})
export class SendEmail {
  formData = {
    name: '',
    phone: '',
    email: '',
    message: '',
  };
  getFormData() {
    console.log(this.formData);

    emailjs
      .send(
        'service_rkfukey', //service id
        'template_su4mjk9', //template id
        {
          ...this.formData,
        },
        'N3xga7GAtw352Ac-q' //public id
      )
      .then((data) => {
        alert('Email Send Successfully...');
        console.log(data);
      })
      .catch((err) => {
        console.log(err);
      });

    this.formData.name = '';
    this.formData.email = '';
    this.formData.message = '';
    this.formData.phone = '';
  }
}
