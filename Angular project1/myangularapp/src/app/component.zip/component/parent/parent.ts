import { Component, NgModule } from '@angular/core';
import { Child } from '../child/child';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-parent',
  imports: [Child, FormsModule],
  templateUrl: './parent.html',
  styleUrl: './parent.css',
})
export class Parent {
  taskId: number = 0;
  taskName: string = '';
  taskCreatedDates: any = null;
  noOfDays: number = 0;
  taskStatus: string = '';
  taskDeadLine: string = '';
  taskDetails: Array<Object> = [];
  details: Object = {};

  addTask() {
    this.taskId = this.taskId + 1;
    this.taskCreatedDates = new Date();
    this.details = {
      id: this.taskId,
      name: this.taskName,
      cDate: this.taskCreatedDates,
      status: this.taskStatus,
      noOfDays: this.noOfDays,
      deadline: this.taskDeadLine,
    };
    this.taskDetails.unshift(this.details);
    console.log(this.taskDetails);
  }
}
