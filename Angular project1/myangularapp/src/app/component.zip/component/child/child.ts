import { DatePipe } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-child',
  imports: [DatePipe],
  templateUrl: './child.html',
  styleUrl: './child.css',
})
export class Child {
  @Input() taskDetails: Array<any> = [];
  deleteVisible: boolean = true;
  updatedDetails: Array<any> = [];

  editData(data: Object) {}
  deleteData(data: any) {
    console.log(data);
    this.deleteVisible = false;
    this.updatedDetails = this.taskDetails.filter((p) => {
      return p.id != data.id;
    });
  }
}
