import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayEmpDetails } from './display-emp-details';

describe('DisplayEmpDetails', () => {
  let component: DisplayEmpDetails;
  let fixture: ComponentFixture<DisplayEmpDetails>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DisplayEmpDetails]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DisplayEmpDetails);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
