import { Component } from '@angular/core';
import { Input } from '@angular/core';
@Component({
  selector: 'app-sample-preview',
  imports: [],
  templateUrl: './sample-preview.html',
  styleUrl: './sample-preview.css',
})
export class SamplePreview {
  @Input() name = '';
  @Input() email = '';
  @Input() job_title = '';
}
