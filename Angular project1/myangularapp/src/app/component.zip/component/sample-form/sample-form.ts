import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { SamplePreview } from '../sample-preview/sample-preview';
import { FormsModule } from '@angular/forms';
import emailjs from '@emailjs/browser';

@Component({
  selector: 'app-sample-form',
  imports: [CommonModule, FormsModule, SamplePreview],
  templateUrl: './sample-form.html',
  styleUrl: './sample-form.css',
})
export class SampleForm {
  isDisplaySuccess = true;
  isDisplayError = true;
  errorMessage = '';
  name = '';
  email = '';
  job_title = '';
  skills = '';

  from_mail = 'ashok@rvit.edu.in';

  submitForm() {
    emailjs
      .send(
        'service_rkfukey',
        'template_su4mjk9',
        {
          name: this.name,
          email: this.email,
          job_title: this.job_title,
          from_mail: this.from_mail,
        },
        'N3xga7GAtw352Ac-q'
      )
      .then(() => {
        this.isDisplaySuccess = false;
        this.name = '';
        this.email = '';
        this.job_title = '';
        this.skills = '';
      })
      .catch((err) => {
        this.errorMessage = err;
        this.isDisplayError = false;
      });
  }
}
