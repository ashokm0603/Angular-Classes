import { Component } from '@angular/core';
import { ProductRatings } from '../product-ratings/product-ratings';

@Component({
  selector: 'app-product-details',
  imports: [ProductRatings],
  templateUrl: './product-details.html',
  styleUrl: './product-details.css',
})
export class ProductDetails {
  productDetails: Array<any> = [
    {
      id: 100,
      name: 'ear buds ',
      price: 50000,
      ratings: '',
    },
    {
      id: 101,
      name: 'HP laptop  ',
      price: 90000,
      ratings: '',
    },
    {
      id: 102,
      name: 'IPhone 17 pro max',
      price: 150000,
      ratings: '',
    },
    {
      id: 103,
      name: 'Vivo',
      price: 40000,
      ratings: '',
    },
  ];

  receivedRatings = '';

  receivedRatingsEvent(event: string) {
    this.receivedRatings = event;
  }
}
