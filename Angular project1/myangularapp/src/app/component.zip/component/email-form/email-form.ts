import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { EmailPreview } from '../email-preview/email-preview';
import emailjs from '@emailjs/browser';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-email-form',
  imports: [FormsModule, EmailPreview, CommonModule],
  templateUrl: './email-form.html',
  styleUrl: './email-form.css',
})
export class EmailForm {
  displaySuccess = true;
  displayError = true;
  name = '';
  job_title = '';
  email = '';
  skills = '';

  formSubmit() {
    emailjs
      .send(
        'service_rkfukey', //service id
        'template_su4mjk9', //template id
        {
          name: this.name,
          job_title: this.job_title,
          email: this.email,
        },
        'N3xga7GAtw352Ac-q' //public key
      )
      .then(() => {
        this.displaySuccess = false;
        this.name = '';
        this.job_title = '';
        this.email = '';
        this.skills = '';
      })
      .catch(() => {
        this.displayError = false;
      });
  }
}
