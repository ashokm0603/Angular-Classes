import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

@Component({
  selector: 'app-registration',
  imports: [FormsModule], 
  templateUrl: './registration.html',
  styleUrl: './registration.css',
})
export class Registration {
  name = '';
  email = '';
  phone = '';
  gender = '';

  submittedForm(formData: NgForm) {
    console.log(formData.value);

    alert(`${formData.value.name} , Login Successfully`);
  }
}
