import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../service/product-service';
import { ProductModel } from '../mouse-event/model/product-model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-component',
  imports: [CommonModule],
  templateUrl: './product-component.html',
  styleUrl: './product-component.css',
})
export class ProductComponent implements OnInit {
  productData!: ProductModel[];
  constructor(private pd: ProductService) {}

  ngOnInit(): void {
    this.productData = this.pd.getProductDetails();
  }
}
