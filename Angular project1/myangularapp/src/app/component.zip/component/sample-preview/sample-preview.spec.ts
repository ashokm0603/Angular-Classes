import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplePreview } from './sample-preview';

describe('SamplePreview', () => {
  let component: SamplePreview;
  let fixture: ComponentFixture<SamplePreview>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SamplePreview]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SamplePreview);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
