import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-edit',
  imports: [],
  templateUrl: './admin-edit.html',
  styleUrl: './admin-edit.css'
})
export class AdminEdit {

}
