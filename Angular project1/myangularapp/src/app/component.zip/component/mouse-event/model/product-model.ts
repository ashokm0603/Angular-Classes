export interface ProductModel {
  productId: number;
  name: string;
  price: number;
  ratings: string;
  about: string;
  productImageSrc: string;
}
